import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';

import App from './App';
import {Route, BrowserRouter as Router} from 'react-router-dom'
import EnquireForm from './component/EnquireForm';
import Enquires from './component/Enquires';
import { Provider } from 'react-redux';
import { createStore, applyMiddleware, compose } from 'redux';

import { rootReducer } from './reducers'

import thunk from 'redux-thunk';
import promiseMiddleware from 'redux-promise';


const logger = store => {
    return next => {
        return action => {
            console.log('[Middleware] Dispatching', action);
            const result = next(action);
            console.log('[Middleware] next state', store.getState());
            return result;
        }
    }
}; 



const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;

const store = createStore(
  rootReducer,
  composeEnhancers(
    applyMiddleware(logger, promiseMiddleware)
  )
);


const routing = (
  <Provider store={store}>
    <Router>
      <div>
        <Route exact path='/' component={ App } />
        <Route exact path='/EnquireForm' component={ EnquireForm } />
        <Route exact path='/Enquires' component={ Enquires } />
      </div>
    </Router>
  </Provider>
)

ReactDOM.render(
  routing,
  document.getElementById('root')
);


