

export const getCourses = () => {
    const output = fetch( "http://localhost:6700/courses", { method: "GET" } )
        .then( ( response ) => response.json() );
    return {
        type: 'GET_COURSES',
        payload: output
    }
  }
  
  
    
