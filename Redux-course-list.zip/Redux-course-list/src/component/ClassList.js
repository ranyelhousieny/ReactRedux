import React from 'react';
import { Link } from 'react-router-dom'

const ClassList = ( classList ) => {
    console.log( "Course List", classList );
    const renderList = ({classList}) => {
        console.log( "props ", classList );
        if ( classList ) {
            console.log("ProdList inside if", classList)
            return classList.map((data) => {
                return(
                    <li key={ data.id }>{ data.name }
                        <ul>
                            <li>
                                course price: ${data.price}
                            </li>
                            <li>
                                <button>
                                    <Link to='/EnquireForm'>
                                        Enquire
                                    </Link>
                                </button>
                            </li>
                        </ul>
                    </li>
                )
            })
        }
    }

    
 
    return(
        <div className="container">
            <div  className="row">
                <ul>{renderList(classList)}</ul>
            </div>
        </div>
    )
    
}

export default ClassList;