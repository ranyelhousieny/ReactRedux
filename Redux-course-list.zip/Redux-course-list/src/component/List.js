import React from 'react';

const List = ( props ) => {
    const items = props.items;
    const itemsList = items.map( ( item ) => 
        <li>{ item }</li> )
    
    return (
        <div>
            <ul>{ itemsList }</ul>
        </div>
    )
}

export default List;