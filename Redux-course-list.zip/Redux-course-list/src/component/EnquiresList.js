import React from 'react';

const EnquireList = ( props ) => {
    const students = props.students;
    console.log( "Students : ", students );
    
    const listStudents = students.map( ( student ) => {
        
        return (
            <li key={ student.id }>
                Enquiree {student.id } name : { student.name }
        </li> );
    } );

    return (
        <div>
            <ul>{ listStudents }</ul>
        </div>
    )
}

export default EnquireList;