import React from 'react'
import Header from './Header';
const url = "http://localhost:6700/students"
class EnquireForm extends React.Component {
    constructor () {
        super()
        this.state = {name: ''}
    }

    changeHandler = ( event ) => {
        this.setState({name: event.target.value})
    }

    
    submitHandler = ( event ) => {
        const request = {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(this.state)
        }
        fetch( url, request );
    }
    
    render () {
        return (
            <form>
                <Header />
                <h1>Welcome { this.state.name }</h1>
                <label>
                    Name:
                    <input
                        type='text'
                        onChange={ this.changeHandler }
                        name='name'
                    />
                </label>
                <button onClick={ this.submitHandler }>submit</button>

            </form>
        );
    }
}

export default EnquireForm;