import React from 'react';
import EnquireList from './EnquiresList';
import Header from './Header';

const url = "http://localhost:6700/students";
class Enquires extends React.Component {
    constructor () {
        super();
        this.state = {
            students: ''
        }
        console.log("Inside Enquires students: ", this.state.students)
    }

    componentDidMount () {
        console.log( "componentDidMount : ", this.state.students );
        fetch( url, { 'method': 'GET' } )
            .then( ( response ) => response.json() )
            .then( ( data ) => {
                this.setState( { students: data } );
            } );
        console.log( "From the server : ", this.state.students );
    }

    render () {
        console.log( "Students after server :", this.state.students )
        if ( !this.state.students )
            return (<h1>componentDidMount did not fire</h1>)
        
        return (
            <div>
                <Header />
                <h1>Enquires List</h1>
                <EnquireList students={this.state.students} />
            </div>
        )
    }
}

export default Enquires;