

const initialState = {
  courses: [
    {
      'id': -1,
      'name': 'No Courses'
    }
  ]
}

export const rootReducer = ( state = initialState, action ) => {
  console.log( 'inside the reducer', action.type );
  switch ( action.type ) {
    case 'ADD_CLASS':
      return {
        ...state,
        courses: [ ...state.courses,
          {
            id: -2,
            name: "Learn Redux"
        }]
        
      }
    
    case 'GET_COURSES':
      return {
        courses: action.payload
      }
    default:
      return state;
};
}