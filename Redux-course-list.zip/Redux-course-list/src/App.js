import './App.css';
import React from 'react';
import ClassList from './component/ClassList';
import Header from './component/Header'
import { connect } from 'react-redux'
import { getCourses } from './actions'

const url = "http://localhost:6700/courses"
class App extends React.Component {
  constructor () {
    super();
    this.state = {
        courses: ''
    }
  }

  componentDidMount () {
    console.log( "Inside componentDidMount courses: ", this.state.courses );
    this.props.GetCourseList(); 
    

    fetch( url, { method: 'GET' } )
      .then( ( response ) => response.json() )
      .then( ( data ) => {
        this.setState( {courses: data} );
      } );
    
    

  }

  
  render () {
    console.log( "Courses received from Server: ", this.state.courses );
    return (
      <div>
        <Header />
        <h1>Rany's Courses</h1>
        <ul>
          <li>
            <button onClick={ this.props.GetCourseList }>Get Latest Classes from Server</button>
            <ClassList classList={ this.props.courses }/>
          </li>
        </ul>
      </div>
    )
  }
}

// Get the state as props
const mapStateToProps = ( state ) => {
  return {
    courses: state.courses
  };
};


const mapDispatchToProps = ( dispatch ) => {
  console.log('inside mapDispatchToProps')
  return {
    GetCourseList: () => {
      dispatch( getCourses() );
    }
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(App)
